Todo List API Documentation

This documentation outlines the available endpoints, request payloads, and response structures for the Todo List API.

The base URL for all API endpoints is: 'localhost:3000'

Endpoints
1. Create a Todo item

Endpoint: /todos
HTTP Method: POST
Request Payload:
  {
  "title": "Sample Task",
  "description": "This is a sample task.",
  "status": false
}
Response:
{
  "_id": "6500b649c404a0928096d61e",
  "title": "Sample Task",
  "description": "This is a sample task.",
  "status": false,
  "createdAt": "2023-09-12T19:04:41.430Z",
  "updatedAt": "2023-09-12T19:04:41.430Z"
}

2. Get All Todo items
Endpoint: /todos
HTTP Method: GET
Response:
[
  {
    "_id": "task_id_1",
    "title": "Sample Task 1",
    "description": "This is the first sample task.",
    "status": false,
    "createdAt": "timestamp",
    "updatedAt": "timestamp"
  },
  {
    "_id": "task_id_2",
    "title": "Sample Task 2",
    "description": "This is the second sample task.",
    "status": true,
    "createdAt": "timestamp",
    "updatedAt": "timestamp"
  }
]

3. Get Task by ID
Endpoint: /todos/:id
HTTP Method: GET
Response: 
{
  "_id": "task_id",
  "title": "Sample Task",
  "description": "This is a sample task.",
  "status": false,
  "createdAt": "timestamp",
  "updatedAt": "timestamp"
}

4. Update Task by ID
Endpoint: /todos/:id
HTTP Method: PATCH
Request Payload: 
{
  "title": "Updated Task Title",
  "status": true
}
Response:
{
  "_id": "task_id",
  "title": "Updated Task Title",
  "description": "This is a sample task.",
  "status": true,
  "createdAt": "timestamp",
  "updatedAt": "timestamp"
}

5. Delete Task by ID
Endpoint: /todos/:id
HTTP Method: DELETE
Response:
{
  "_id": "task_id",
  "title": "Updated Task Title",
  "description": "This is a sample task.",
  "status": true,
  "createdAt": "timestamp",
  "updatedAt": "timestamp"
}
##################
Error Responses
1. 400 Bad Request

2. 404 Not Found

3. 500 Internal Server Error

4. 201 Created

5. 200 OK

###################
If you try to update the item with the key which doesn't exist in allowedUpdates array then it should send the response as follows:
{
    "error": "Invalid updates!"
}





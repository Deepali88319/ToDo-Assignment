const mongoose = require("mongoose")

const dbConnect = async () =>{
    try{ 
        // const connection = await mongoose.connect("mongodb+srv://deepalinarang:deepali@cluster0.ur5aoja.mongodb.net/todo-app?retryWrites=true&w=majority")
        const connection = await mongoose.connect(process.env.MONGODB_URL)
        console.log("Successfully connected!!!")
    }catch(e){
        console.log(e)
    }
 
}

module.exports = dbConnect;
const express = require('express');
const Task = require('../models/todo');
const router = express.Router(); 
const app = express()

router.post('/todos', async (req,res)=>{
    const task = new Task(req.body);
  
  try{
   const savedTask = await task.save();
      res.status(201).send(savedTask);
     
  }catch(e){
      res.status(400).send(e);
  }
  
  });

router.get('/todos', async (req,res)=>{

const sortOptions = {};
if (req.query.sort) {
  const parts = req.query.sort.split(':');
  sortOptions[parts[0]] = parts[1] === 'desc' ? -1 : 1;
}
// Return tasks based on sort,limit and skip query parameter
    try{
        const tasks = await Task.find({})
        .sort(sortOptions)
        .limit(parseInt(req.query.limit))
        .skip(parseInt(req.query.skip));
        res.status(200).send(tasks);
    }catch(e){
        res.status(500).send(e);
    }
});

router.get('/todos/:id',async (req,res)=>{
    try{
       const task = await Task.findById(req.params.id);
       if(!task){
          return res.status(404).send();
       }
       res.status(200).send(task);
    }catch(e){
      res.status(500).send(e);
    }
  });


router.patch('/todos/:id',async (req,res)=>{
    const updates = Object.keys(req.body);
    const allowedUpdates = ['description','title','status'];
    const isValidOperation = updates.every((update)=> allowedUpdates.includes(update))

    if(!isValidOperation){
        return res.status(400).send({ error: 'Invalid updates!' })
    }
    try{
    const updatedTask =  await Task.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    
    if (!updatedTask) {
      return res.status(404).send()
  }
  
    res.send(updatedTask)
    }catch(e){
     res.status(400).send(e);
    }
});

router.delete('/todos/:id',async (req,res)=>{
   
    try{
      const deletedTask = await Task.findByIdAndDelete(req.params.id);
      if(!deletedTask){
        return res.status(404).send();
      }
      res.send(deletedTask);
    }catch(e){
      res.status(500).send(e);
    }
  
  });

module.exports = router;


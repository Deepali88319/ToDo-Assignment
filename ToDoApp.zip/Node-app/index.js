const express = require('express')
const dbConnect = require('./utils/db')
const TaskRouter = require('./routers/todo')
const app = express()


// const PORT = 3000
const port = process.env.PORT;
dbConnect();

app.use(express.json())
app.use(TaskRouter);

app.listen(port,()=>{
    console.log("Server running on port",port)
})
